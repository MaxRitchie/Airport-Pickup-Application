package models;

public class AirlineModel {
    public String name;
    public String iata;
    public String icao;
}
