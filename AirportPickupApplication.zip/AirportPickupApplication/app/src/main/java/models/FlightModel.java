package models;

public class FlightModel {
    public String number;
    public String iata;
    public String icao;
    public String codeshared;
}
