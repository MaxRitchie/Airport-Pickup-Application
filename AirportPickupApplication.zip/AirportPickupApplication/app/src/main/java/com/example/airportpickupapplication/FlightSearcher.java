package com.example.airportpickupapplication;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import java.util.ArrayList;

public class FlightSearcher extends Fragment {

    String flightCode = "";
    EditText flightCodeInput;

    FlightInfoService flightInfoService;

    SpeechToTextHandler speechToTextHandler = new SpeechToTextHandler();

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.flight_searcher_screen, container, false);
        flightInfoService = new FlightInfoService(getContext());

        flightCodeInput = view.findViewById(R.id.flightCodeInputEditText);

//        getVoiceInput(view);
        displayManager(view);

        return view;
    }


    public void displayManager(View view) {
        Button searchFlightButton = (Button) view.findViewById(R.id.searchFlightButton);

        searchFlightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                flightCode = getFlightCode(view);
                if (!flightCode.equals("") && !flightCode.equals(null)) {
                    searchFlightCode(flightCode);
                }


//                FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
//                fragmentTransaction.replace(R.id.fragmentContainer, new FlightInformation());
//                fragmentTransaction.commit();

            }
        });
    }

    public void searchFlightCode(String flightCode) {
        flightInfoService.getFlightStatus(flightCode, new FlightInfoService.VolleyResponseListener() {
            @Override
            public void onError(String message) {
                Toast.makeText(getContext(), "Error", Toast.LENGTH_LONG).show();
            }

            @Override
            public void onResponse(String flightStatus) {
                Toast.makeText(getContext(), "Returned Flight Status: " + flightStatus, Toast.LENGTH_LONG).show();
            }
        });
    }


    public String getFlightCode(View view) {
        String userInput = "";
        String flightCode = "";

        try {
            userInput = flightCodeInput.getText().toString();
            System.out.println("Eat my ass");
            System.out.println("TYPE :: " + flightCodeInput.getClass().getName());
            System.out.println("VALUE :: " + flightCodeInput.getText());
        } catch (NullPointerException exception) {
            Toast.makeText(getContext(), "A Flight Code Must Be Entered", Toast.LENGTH_SHORT).show();
            exception.printStackTrace();
        } catch (Exception exception) {
            Toast.makeText(getContext(), "An Error Has Occurred", Toast.LENGTH_SHORT).show();
            exception.printStackTrace();
        }

        // Validates the inputted flight code from the user.
        return validateFlightCode(userInput);
    }

    /**
     * Validates the input received for the flight code.
     *
     * @param userInput
     * @return
     */
    public String validateFlightCode(String userInput) {
        // If statement used to display an error message when nothing has been entered into the flight code search input/
        if (userInput.equals("")) {
            System.out.println("validateFlightCode() == '' :: " + userInput);
            Toast.makeText(getContext(), "A Flight Code Must Be Entered", Toast.LENGTH_SHORT).show();
            return "";
        } else if (userInput.length() == 6) {
            System.out.println("validateFlightCode() == '' :: " + userInput);
            return userInput;
        } else {
            System.out.println("validateFlightCode() else '' :: " + userInput);
            Toast.makeText(getContext(), "A Valid Flight Code Must Be Entered", Toast.LENGTH_SHORT).show();
            return "";
        }
    }

//    public void getVoiceInput(View view) {
//        Button speechToTextButton = (Button) view.findViewById(R.id.speechToTextButton);
//
//        speechToTextButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                speechToTextHandler.onClick(view);
//            }
//        });
//    }
}

