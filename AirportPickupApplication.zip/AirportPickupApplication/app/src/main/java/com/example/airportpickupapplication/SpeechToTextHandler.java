package com.example.airportpickupapplication;

import android.content.ActivityNotFoundException;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.speech.RecognizerIntent;
import android.widget.EditText;
import android.view.View;

import java.util.ArrayList;

public class SpeechToTextHandler extends AppCompatActivity {

    private static final int REQUEST_CODE = 100;
    private EditText flightCodeInputEditText;

    // Sets the content view for the Main Activity
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.flight_searcher_screen);
        flightCodeInputEditText = (EditText) findViewById(R.id.flightCodeInputEditText);
    }

    // This method gets called when the button is clicked
    public void onClick(View v)

    //Create an Intent with “RecognizerIntent.ACTION_RECOGNIZE_SPEECH” action//
    {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);

        try {
            // Starts the activity and waits for a response
            startActivityForResult(intent, REQUEST_CODE);
            // Catches any exceptions and displays them in the command line
        } catch (ActivityNotFoundException e) {
            e.printStackTrace();
        }
    }

    // This method handles the results
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case REQUEST_CODE: {
                if (resultCode == RESULT_OK && null != data) {
                    ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    flightCodeInputEditText.setHint(result.get(0));
                }
                break;
            }
        }
    }
}
