package com.example.airportpickupapplication;

import android.content.Context;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONObject;

import java.sql.Time;

import models.FlightDataModel;

public class FlightInfoService {

    public static final String QUERY_FOR_FLIGHT_CODE = "https://api.aviationstack.com/v1/flights?access_key=1049b1c77de5e11237ff142fef6fb370&limit=1&flight_iata=";

    Context context;
    String flightCode;
    String flightStatus;
    Time landTime;
    Time timeToLeave;
    Time leaveInCountDown;

    /**
     * Constructor method for the class.
     *
     * @param context Passes in the context of what class it will be used in.
     */
    public FlightInfoService(Context context) {
        this.context = context;
    }

    public interface VolleyResponseListener {
        void onError(String message);

        void onResponse(String flightStatus);
    }

    public void getFlightStatus(String flightCode, VolleyResponseListener volleyResponseListener) {
        String url = QUERY_FOR_FLIGHT_CODE + flightCode;

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    System.out.println("RESPONSE :: " + response.toString());
                    Gson gson = new Gson();
                    // Flight data on response is contained within an array called data.
                    JSONArray data = response.getJSONArray("data");
                    // Serialise the data from the first element in the array (should never be more).
                    FlightDataModel flightData = gson.fromJson(data.getJSONObject(0).toString(), FlightDataModel.class);

                    flightStatus = flightData.flight_status;

                    Toast.makeText(context, flightStatus, Toast.LENGTH_SHORT).show();

                    volleyResponseListener.onResponse(flightStatus);
                } catch (Exception exception) {
                    System.out.println("ERROR: " + exception.toString());
                    Toast.makeText(context, "Error Accessing Flight Status", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                volleyResponseListener.onError("Error Gaining Flight Status");
            }
        });
        System.out.println("CONTEXT :: " + context);
        APIConnector.getInstance(context).addToRequestQueue(request);
    }
}
